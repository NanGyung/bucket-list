export const theme = {
    background: '#F7FAFC',
    titleBackground: '#3C56B1',
    itemBackground: '#BBD5E4',
    inputBackground: '#1E475F',
    inputText: '#F5F5F5',
    main: '#CAE6F5',
    text: '#1B1B1B',
    titleText: '#fefefe',
    done: '#767C80'
};
